<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Product extends CI_Controller {

    public function Home() {
        parent::__construct();
		$this->load->model("home_model");
    }

    public function category($cate,$type,$title='',$page=1) {
		//echo $cate."===>".$type."==>".$page;
		//echo json_encode($this->getDataFromServer('/api/products/21/1/CategoryID'));
		$data['cate_prod'] 		= $cate;
		$data['type_prod'] 		= $type;
		$data['detail_prod']	= json_decode($this->getDataFromServer('/api/products/21/'.$page.'/CategoryID'));
		$data['controller']	= $this; 
        $this->load->view('list_product', $data);
    }
	public function detail($id) {
		$data['detail_product']	= json_decode($this->getDetailProduct('/api/products/'.$id));;
        $this->load->view('detail_product', $data);
    }
	public function getDataFromServer($qry_str){
		$curl = curl_init($this->config->item('maisya_server').$qry_str);
		curl_setopt($curl, CURLOPT_FAILONERROR, true);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);  
		$result = curl_exec($curl);
		return $result; 
	}
	
	public function getDetailProduct($qry_str){
		//echo $this->config->item('maisya_server').$qry_str;
		$curl = curl_init($this->config->item('maisya_server').$qry_str);
		curl_setopt($curl, CURLOPT_FAILONERROR, true);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);  
		$result = curl_exec($curl);
		return $result;
	}

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
