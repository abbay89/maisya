<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class About_us extends CI_Controller {

    public function About_us() {
        parent::__construct();
    }

    public function delivery_term() {
        $this->load->view('static_page/delivery_term');
    }

    public function diamond_guide() {
        $this->load->view('static_page/diamond_guide');
    }


}

?>
