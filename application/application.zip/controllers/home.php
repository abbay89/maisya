<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends CI_Controller {

    public function Home() {
        parent::__construct();
		$this->load->model("home_model");
		$this->load->model("user_model");
    }

    public function index() {
		$data['all_slide']	=	$this->home_model->get_slideshow();
		$data['all_promo']	=	$this->home_model->get_promo();
		$data['all_events']	=	$this->home_model->get_events();
        $this->load->view('home', $data);
    }
	public function register() {
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('password', 'Password', 'trim|required|matches[confirm-password]');
        $this->form_validation->set_rules('confirm-password','Repeat Password', 'trim|required');
        
		$customer = Array();
		$customer['cust_username'] = $this->input->get_post('email', TRUE);
		$customer['cust_password'] = sha1($this->input->get_post('password', TRUE));
		$customer['cust_name'] = $this->input->get_post('fullname', TRUE);
		$customer['cust_phone'] = $this->input->get_post('phone', TRUE);
		$customer['cust_email'] = $this->input->get_post('email', TRUE);
		$customer['cust_other_phone'] = $this->input->get_post('phone', TRUE);
		$customer['cust_regdate'] = date("Y-m-d H:i:s");
		
		$ca['cust_id'] = $this->user_model->insert_customer($customer);
		if ($ca['cust_id']) {
			$this->session->set_flashdata('message', $this->session->userdata('language') != 'en' ?
			'Selamat! Registrasi berhasil. Silakan login untuk melanjutkan' :
			'Congratulation! You are now registered. Please login to continue');
			$this->session->set_userdata('cust_id', $ca['cust_id']);
            $this->session->set_userdata('cust_name', $customer['cust_name']);
            $this->session->set_userdata('cust_username', $customer['cust_email']);
		}
		redirect(base_url());
    }
	public function login() {
        $username = $this->input->get_post('username', TRUE);
        $password = $this->input->get_post('password', TRUE);
        $redirect = $this->input->get_post('redirect', TRUE);
        $shapassword = sha1($password);
        $cust_id = $this->user_model->auth_customer($username, $shapassword);
        if ($cust_id) {
            $this->session->set_userdata('cust_id', $cust_id->cust_id);
            $this->session->set_userdata('cust_name', $cust_id->cust_name);
            $this->session->set_userdata('cust_username', $cust_id->cust_username);
        } else {
            if ($redirect == 'checkout') {
                $this->session->set_userdata('message','Wrong username or Password');
            } else {
                $this->session->set_flashdata('message','Wrong username or Password');
            }
        }
        $this->session->unset_userdata('redirect');
        redirect(base_url() . '/' . $redirect);
    }
	public function logout() {
        $this->session->unset_userdata('who');
        $this->session->sess_destroy();
        redirect(base_url());
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
