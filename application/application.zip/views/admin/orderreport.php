<section id="content" class="">
	<div class="row">
		
		<div class="col-md-12 col-sm-12 col-xs-12">	
			<div class="x_panel">
				<iframe src="<?php echo base_url()?>report/order/" width="100%" style="position: absolute; min-height: 700px; border: none" id="ifoff"></iframe>
			</div>
		</div>
	</div>
</section>