	<div id="footer">
		<span class="back-top transition5s" style="display:none">
		  <span class="icon-up-arrow">
		  </span>
		</span>
		<div class="clearfix">
			<div class="">
				<div class="clearfix">
					<div class="footermenublock">
						<div class="clearfix">
							<div class="footermenu">
								<div class="row ftr-top">
									 
								</div>
								<div class="container ftr-menu">
									<ul class="row">	
										<li class="col-xs-12 col-md-2 col-sm-2 ">
											<span  > <i class="far fa-envelope-open"></i> &nbsp; Contact</span> 
											
										</li>
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > <i class="far fa-user"></i> &nbsp; Chat Available</span> 
											
										</li>
										
										<li class="col-xs-12 col-md-2 col-sm-2 ">
											<span> <img width="30px" src="<?php echo base_url()?>assets/img/Footer-Logo.png" /></span> 
											
										</li>
										<li class="col-xs-12 col-md-2 col-sm-2 ">
											<span  > <i class="fas fa-search"></i> &nbsp; Order Status</span> 
											
										</li>
										<li class="col-xs-12 col-md-3 col-sm-3  pull-right">
											<span  > <i class="fas fa-map-marker-alt"></i> &nbsp; Store Location </span> 
											
										</li>
									</ul>
								</div>
								
							</div>
							<div class="bottom-footer">
								<div class="container">
									<ul class="row">	
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > Help</span> 
											<ul>
												<li class="no-child">
													<a href="#">Contact Us</a>
												</li>
												<li class="no-child">
													<a href="#">Place an Order</a> 
												</li>
												<li class="no-child">
													<a href="<?php base_url()?>delivery_term">Delivery</a>
												</li>
												<li class="no-child">
													<a href="#">Warranty And Maintenance</a>
												</li>
											</ul>
										</li>
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > Information</span> 
											<ul>
												<li class="no-child">
													<a href="#">Terms And Policy</a>
												</li>
												<li class="no-child">
													<a href="#">Privacy Policy</a> 
												</li>
												<li class="no-child">
													<a href="#">Buy Back / Exchange Policy</a>
												</li>
												<li class="no-child">
													<a href="#">FAQ</a>
												</li>
											</ul>
										</li>
										
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > Guide & Education</span> 
											<ul>
												<li class="no-child">
													<a href="#">How To Take Care Of Jewelry</a>
												</li>
												<li class="no-child">
													<a href="#">Guide Ring Size</a> 
												</li>
												<li class="no-child">
													<a href="<?php base_url()?>diamond_guide">Diamond Guide</a>
												</li>
												<li class="no-child">
													<a href="#">Blog</a>
												</li>
											</ul>
										</li>
										
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<img src="<?php echo base_url();?>assets/img/footer/foot1.jpg">
										</li>
										
									</ul>
									
									<div class="col-xs-12 col-md-12 col-sm-12 line"></div>
									<ul class="row">	
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > Customer Service</span> 
											<ul>
												<li class="no-child">
													<a href="#">0818 148 982</a>
												</li>
												<li class="no-child">
													<a href="#">Senin - Jumat</a> 
												</li>
												<li class="no-child">
													<a href="#">09.00 - 17.00</a>
												</li>
												<li class="no-child">
													<a href="#">maisyajewelleryid@yahoo.com</a>
												</li>
											</ul>
										</li>
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > Head Office</span> 
											<ul>
												<li class="no-child">
													<a href="#">Gedung Maisya</a>
												</li>
												<li class="no-child">
													<a href="#">Jln. Pahlawan Revolusi No.2</a> 
												</li>
												<li class="no-child">
													<a href="#">Pondok Bambu</a>
												</li>
												<li class="no-child">
													<a href="#">Jakarta 13430</a>
												</li>
											</ul>
										</li>
										
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > Delivery Service</span> 
											<ul>
												<li class="no-child">
													<a href="#">
														<img src="<?php echo base_url();?>assets/img/footer/jne.jpg">
													</a>
												</li>
											</ul>
										</li>
										
										<li class="col-xs-12 col-md-3 col-sm-3 ">
											<span  > Payment Service</span> 
											<ul>
												<li class="no-child">
													<img src="<?php echo base_url();?>assets/img/footer/pay.jpg">
												</li>
											</ul>
										</li>
										
									</ul>
								
								</div>
							</div>
						</div>
					</div>
				</div>
			</div> 
		</div>		
	</div>
	<div class="col-xs-12 col-md-12 col-sm-12 btm-form">
		<div class="container">    
			<ul class="row">	
				<li class="col-xs-12 col-md-6 col-sm-6">
					
					<ul>
						<h2>
							Let's stay in touch 
						</h2>
						<li class="no-child row">
							<div class="col-xs-12 col-md-5 col-sm-6">
								Sign up to our email newsletter
							</div>
							<div class="col-xs-7 col-md-7col-sm-7">
								<input type="text" class="email" placeholder="Enter Your Email Address">
								<input type="submit" value="Submit" class="email" />
							</div>
						</li>
					</ul>
					
				</li>
				<li class="col-xs-12 col-md-6 col-sm-6">
					<ul>
						<h2>
							Follow Us
						</h2>
						<li class="no-child">
							
							<div class="col-xs-2 col-md-2 col-sm-2">
							
							</div>
							<div class="col-xs-10 col-md-10 col-sm-10">
								<a href="#">
									<img src="<?php echo base_url()?>assets/img/fb.png" />
								</a>&nbsp;&nbsp;
								<a href="#">
									<img src="<?php echo base_url()?>assets/img/istagram.png" />
								</a> &nbsp;&nbsp;
								<a href="#">
									<img src="<?php echo base_url()?>assets/img/youtube.png" />
								</a>
							</div>
						</li>
					</ul>
				</li>
			</ul>			
		</div>
	</div>
	<script>
		$(document).ready(function(){
			$(".dropdown").hover(
					function() { 
						$('.dropdown-menu', this).stop().fadeIn("fast");
					},
					function() { $('.dropdown-menu', this).stop().fadeOut("fast");
					}
				);
		});
	</script>
	<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
			
			<ul class="nav nav-pills">
				<li class="active"><a data-toggle="pill" href="#sign-in">Sign In</a></li>
				<li class="pull-right"><a data-toggle="pill" href="#registration">Registration</a></li>
			</ul>
			  
			  <div class="tab-content">
				<div id="sign-in" class="tab-pane fade in active">
					<form action="<?php echo base_url() ?>home/login" method="post">
						<div class="form-group">
							<input type="text" class="form-control" id="email" name="username" placeholder="email">
						</div>
						<div class="form-group">
							<input type="password" class="form-control" id="password" name="password" placeholder="password">
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-signin col-xs-12 ">Sign In</button>
						</div>
						<div class="form-group">
							<label for="exampleFormControlInput1" class="col-xs-12 col-md-12 col-sm-12">Forgot Password</label>							
						</div>
						<div class="form-group">
							<label for="exampleFormControlInput1" class="col-xs-12 col-md-12 col-sm-12">Or sign in with these accounts</label>
						</div>
						<div class="form-group">
							<button type="button" class="btn btn-primary col-xs-12 ">Sign In with Facebook</button>
						</div>
						<div class="form-group">
							<button type="button" class="btn btn-google col-xs-12 ">Sign In with Google</button>
						</div>
					</form>
				</div>
				<div id="registration" class="tab-pane fade">
					<form action="<?php echo base_url()?>home/register" onsubmit="return validateForm()"  name="frmReg" method="post">
						<div class="form-group">
							<input type="text" class="form-control" id="fullname" name="fullname" placeholder="Full Name">
						</div>
						<div class="form-group">
							<input type="text" class="form-control" id="email" name="email" placeholder="email">
						</div>
						<div class="form-group">
							<input type="text" class="form-control" id="phone" name="phone" placeholder="Mobile Number">
						</div>
						<div class="form-group">
							<input type="password" class="form-control" id="password" name="password" placeholder="password">
						</div>
						<div class="form-group">
							<input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password">
						</div>
						<div class="form-check">
							<input type="checkbox" class="form-check-input" id="checkAgree">
							<label class="form-check-label" for="exampleCheck1">
								I Agree to the terms of use and privacy statement
							</label>
						</div>
						<div class="form-group">
							<button type="submit" id="btn-register" class="btn btn-signin col-xs-12 ">Register Now</button>
						</div>
						<div class="form-group">
							<label for="exampleFormControlInput1" class="col-xs-12 col-md-12 col-sm-12">Forgot Password</label>
							
						</div>
						<div class="form-group">
							<label for="exampleFormControlInput1" class="col-xs-12 col-md-12 col-sm-12">Or sign in with these accounts</label>
						</div>
						<div class="form-group">
							<button type="button" class="btn btn-primary col-xs-12 ">Sign In with Facebook</button>
						</div>
						<div class="form-group">
							<button type="button" class="btn btn-google col-xs-12 ">Sign In with Google</button>
						</div>
					</form>
				</div>
			  </div>

        </div>
        
      </div>
      
    </div>
  </div>
	<script>
		$(document).ready(function(){
			$('#btn-register').attr("disabled", "disabled");
			$("#checkAgree").click(function(){
				if ( $('#checkAgree').is(':checked') ) {
					$('#btn-register').removeAttr("disabled");
				} 
				else {
					$('#btn-register').attr("disabled", "disabled");
				}
			});
			
			
		});
		
		function validateForm() {
			var fullname 		= document.forms["frmReg"]["fullname"].value;
			var email 			= document.forms["frmReg"]["email"].value;
			var phone 			= document.forms["frmReg"]["phone"].value;
			var password 		= document.forms["frmReg"]["password"].value;
			var confirmPassword = document.forms["frmReg"]["confirmpassword"].value;
			if (fullname == "") {
				alert("Fullname is Empty");
				document.forms["frmReg"]["fullname"].setAttribute("style", "border-bottom:1px solid red;");
				return false;
			}
			if (email == "") {
				alert("Email is Empty");
				document.forms["frmReg"]["email"].setAttribute("style", "border-bottom:1px solid red;");
				return false;
			}
			if (phone == "") {
				alert("Phone is Empty");
				document.forms["frmReg"]["phone"].setAttribute("style", "border-bottom:1px solid red;");
				return false;
			}
			if (password == "") {
				alert("Passeword is Empty");
				document.forms["frmReg"]["password"].setAttribute("style", "border-bottom:1px solid red;");
				return false;
			}
			if (password != confirmPassword) {
				alert("Wrong Password");
				document.forms["frmReg"]["password"].setAttribute("style", "border-bottom:1px solid red;");
				document.forms["frmReg"]["confirmpassword"].setAttribute("style", "border-bottom:1px solid red;");
				return false;
			}
		}
	</script>	
	</body>
</html>

  
		