<!DOCTYPE html>
<html ng-app="myapp">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Maisya Jewellery Indonesia</title>
    <meta name="description" content="Maisya Jewellery Indonesia Portal in Indonesia" />
    <meta name="viewport" content="width=device-width">
    <meta name="Keywords" content="Maisya Jewellery Indonesia Portal in Indonesia" />
    <link rel="image_src" href="img/logo.png" />
    <meta property="og:title" content="Maisya Jewellery Indonesia Online Jewellery Portal in Indonesia"/>
    <meta property="og:image" content="img/logo.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta name=HandheldFriendly content=true />
	<meta name=apple-mobile-web-app-capable content=YES />	
	<link rel="icon" href="img/logo.ico" type="image/x-icon" />
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Garamond' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="<?php echo base_url() ?>/assets/css/bootstrap.min.css">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/assets/css/slider.css" />	
	<link href="<?php echo base_url() ?>/assets/css/skdslider.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>/assets/jq_ui/jquery-ui.css" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo base_url() ?>/assets/css/style.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url() ?>/assets/css/simplePagination.css"/>


	
	<script src="<?php echo base_url() ?>/assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>/assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url() ?>/assets/js/custom.js"></script>
	<script src="<?php echo base_url() ?>/assets/js/skdslider.min.js"></script>
	<script src="<?php echo base_url() ?>/assets/jq_ui/jquery-ui.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>/assets/js/jquery.simplePagination.js"></script>
	<script>
		var  base_url = '<?php echo base_url() ?>';
	</script>
	
  </head>
	<body>