		<?php
			$this->load->view('template/header');
			$this->load->view('template/navigation');
		?>
			
		<div class="container">				
			<div class="space-top">
				<div class="row">
					<div class="col-xs-12 col-md-12 col-sm-12 slider">
						<div class="col-xs-12 col-md-3 col-sm-3 category">
							<div id="accordion">
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>PRICE</span></h3>
							  <div>
									
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; IDR 100K - 5M</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; IDR 5M - 10M</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; IDR 10M - 50M</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; IDR 50M+</div>
									
							  </div>
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>GENDER</span></h3>
							  <div>
									
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; MEN</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; WOMEN</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; BABY</div>
									
							  </div>
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>COLLECTION</span></h3>
							  <div>
									
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; ALL RINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; GEMSTONE RINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; ENGAGEMENT RINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; MEN'S RINGS</div>
									
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; SOLITAIRE RINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; WEDDING RINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; ALL EARRINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; EVERYDAY</div>
									
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; SOLITAIRE EARRINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; LITTLE LOVELIES</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; STUD EARRINGS</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; ALL BRACELETS</div>
									
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; BANGLE</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; CHAIN</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; DIAMOND FASHION</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; COLORED DIAMOND</div>
									<div class="lst-checkbox"><input type="checkbox" value=""> &nbsp; BRIDAL SETS</div>
									
							  </div>
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>DISCOUNT</span></h3>
							  <div>
								<p>
								Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer
								ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit
								amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut
								odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate.
								</p>
							  </div>
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>METAL TYPE</span></h3>
							  <div>
								<p>
								Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer
								ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit
								amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut
								odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate.
								</p>
							  </div>
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>SHAPE</span></h3>
							  <div>
								<p>
								Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer
								ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit
								amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut
								odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate.
								</p>
							  </div>
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>CUSTOMER REVIEW</span></h3>
							  <div>
								<p>
								Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer
								ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit
								amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut
								odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate.
								</p>
							  </div>
							  <h3><span  class='head-acc col-xs-12 col-md-12 col-sm-12'>STONE TYPE</span></h3>
							  <div>
								<p>
								Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer
								ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit
								amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut
								odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate.
								</p>
							  </div>
							</div>
						</div>
						<div class="col-xs-12 col-md-9 col-sm-9 category">
							<div class=" col-xs-12 col-md-12 col-sm-12 top-catalog ">
								Filter :
							</div>
							<div class=" col-xs-12 col-md-12 col-sm-12 all-catalog ">
								<?php
									
									foreach($detail_prod->ProductList as $listProduct){
								?>
								<div class="col-xs-12 col-md-4 col-sm-4 lst-ctl">
									
									<div class="thumbnail">
										<div class="icon-wh">
											<i class="far fa-heart"></i>
										</div>
										<a href="<?php echo base_url()."detailproduct/".$listProduct->ProductID; ?>">
											<img src="http://cl.maisya.co.id:5060/api/ProductImages?kodeitem=<?php echo $listProduct->ProductID?>" class="img-thumbnail" height="200px" alt="e"> 
											<div class="caption">
												<p><?php echo $listProduct->ProductName?></p>
												<p class="price">
													IDR <?php echo number_format($listProduct->UnitPrice)?>
												</p>
											</div>
										</a>
									</div>
								</div>
								<?php
									}
								?>
								<div class="col-xs-12 col-md-12 col-sm-12 text-center">
									<div id="pagingHere" class="text-center"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script>
			$( function() {
				
				var url = window.location.pathname;
				var array = url.split('/');
				console.log(array);
				var lastsegment = array[array.length-1];
				if(lastsegment > 0)
				{
					var pager = lastsegment;
				}
				else
				{
					var pager = 1;
				}
				var icons = {
					 header: "iconClosed",    // custom icon class
					 activeHeader: "iconOpen" // custom icon class
				};
				jQuery('#accordion').accordion({ icons: icons,
					autoHeight: false,
					collapsible: true,
					navigation: true,
					heightStyle: "content"					});
				$('#accordion').find('[data-content]').resize();
				$("#pagingHere").pagination({
					items: <?php echo $detail_prod->TotalCount ?>,
					itemsOnPage: 21,
					cssStyle: 'light-theme',
					onPageClick:function(pageNumber,event){
						location.href = base_url +array[2]+"/"+array[3] + "/"+array[4]+"/"+array[5]+"/page/"+pageNumber;
					},
					currentPage: pager
				});
  
				  
			} );
		</script>
		<?php
			$this->load->view('template/footer');
		?>


