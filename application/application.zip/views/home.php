		<?php
			$this->load->view('template/header');
			$this->load->view('template/navigation');
		?>
		
		<!--SLider -->
		<div class="row">
			<div class="col-xs-12 col-md-12 col-sm-12 slider">
				<div id="demo1">
					<?php foreach ($all_slide as $lst_slide){ ?>
						<div class="slide">
							<img src="<?php echo base_url()?>assets/uploads/slideshow/<?php echo $lst_slide->slideshow_image?>" />
							
							<div class="slide-desc">
								<h2><?php echo $lst_slide->slideshow_title?></h2>
								<p><?php echo strip_tags($lst_slide->slideshow_desc)?></p>
							</div>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<!--end SLider -->
				
		<div class="container">				
			<div class="space-top">
				<div class="row">
					<div class="col-xs-12 col-md-12 col-sm-12 ">
						<img  src="assets/img/banner/welcome.png" align="center" class="img-responsive center" alt="">
					</div>
					<div class="col-xs-12 col-md-12 col-sm-12">
						<div class="row">
							<?php foreach ($all_promo as $lst_promo){ 
									if($lst_promo->wh_type == 'Small'){
							?>
										<div class="col-xs-6 col-md-6 col-sm-12">
											<img  src="<?php echo base_url()?>assets/uploads/promo/<?php echo $lst_promo->wh_image_thumb_url?>" class="img-responsive" alt="">
										</div>
							<?php
									}else{
							?>
										<div class="col-xs-12 col-md-12 col-sm-12">
											<img src="<?php echo base_url()?>assets/uploads/promo/<?php echo $lst_promo->wh_image_thumb_url?>" class="img-responsive" alt="">
										</div>
							<?php
									}
								}
							?>
						</div>
						
					</div>						
					<div class="col-xs-12 col-md-12 col-sm-12 testimonial">
						<h1>
							Customer Testimonial
						</h1>
						<div class="col-xs-12 col-md-3 col-sm-3 box-testimonial">
							<div class="thumbnail testi-1">
								<a href="/w3images/lights.jpg">
									<img src="<?php echo base_url()?>assets/uploads/promo/4883a-Untitled-1.jpg" class="img-circle" alt="e"> 
									<div class="caption">
										<p>
											Kemarin sempat beli Kalung, cincin n anting2. Senang sama model nya. Apalagi anting2 nya pada bilang bagus. Sampe sekarang masih pake cincinnya.
										</p>
										<p>
											Terima kasih <br />semoga sukses selalu.
										</p>
									</div>
								</a>
							</div>
							<div class="title-testi">
								<h3>Rudy hartanto</h3>
								jakarta
							</div>
						</div>
						<div class="col-xs-12 col-md-3 col-sm-3 box-testimonial">
							<div class="thumbnail testi-2">
								<a href="/w3images/lights.jpg">
									<img src="<?php echo base_url()?>assets/uploads/promo/4883a-Untitled-1.jpg" class="img-circle" alt="e"> 
									<div class="caption">
										<p>
											Kemarin sempat beli Kalung, cincin n anting2. Senang sama model nya. Apalagi anting2 nya pada bilang bagus. Sampe sekarang masih pake cincinnya.
										</p>
										<p>
											Terima kasih <br />semoga sukses selalu.
										</p>
									</div>
								</a>
							</div>
							<div class="title-testi">
								<h3>Rudy hartanto</h3>
								jakarta
							</div>
						</div>
						<div class="col-xs-12 col-md-3 col-sm-3 box-testimonial">
							<div class="thumbnail testi-3">
								<a href="/w3images/lights.jpg">
									<img src="<?php echo base_url()?>assets/uploads/promo/4883a-Untitled-1.jpg" class="img-circle" alt="e"> 
									<div class="caption">
										<p>
											Kemarin sempat beli Kalung, cincin n anting2. Senang sama model nya. Apalagi anting2 nya pada bilang bagus. Sampe sekarang masih pake cincinnya.
										</p>
										<p>
											Terima kasih <br />semoga sukses selalu.
										</p>
									</div>
								</a>
							</div>
							<div class="title-testi">
								<h3>Rudy hartanto</h3>
								jakarta
							</div>
						</div>
					</div>
					
					
				</div>
			</div>
		</div>
		
		<div class="col-xs-12 col-md-12 col-sm-12 event-img">
			<div class="container">
				<h1>
					Shop From Our Histagram
				</h1>
				<?php foreach ($all_events as $lst_events){ 
				?>
					<div class="col-xs-12 col-md-3 col-sm-3">
						<img src="<?php echo base_url()?>assets/uploads/promo/<?php echo $lst_events->wh_image_thumb_url?>" class="img-thumbnail" alt="e"> 
					</div>
				<?php } ?>
			</div>
		</div>
		
		<?php
			$this->load->view('template/footer');
		?>
		<script type="text/javascript">
			$(function() {
				 
				jQuery('#demo1').skdslider({
				  slideSelector: '.slide',
				  delay:5000,
				  animationSpeed:3000,
				  showNextPrev:false,
				  showPlayButton:false,
				  autoSlide:true,
				  animationType:'fading'
				});
			});
		</script>
		<!--END Slider -->
